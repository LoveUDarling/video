﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMSException
{

    [Serializable]
    public class PatientException :ApplicationException
    {
        public PatientException() { }
        public PatientException(string message) : base(message) { }
        public PatientException(string message, Exception innerException) : base(message, innerException) { }
      
    }
}
